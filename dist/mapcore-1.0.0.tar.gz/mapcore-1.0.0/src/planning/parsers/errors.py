#
# This file is part of pyperplan.
#


class ParseError(Exception):
    pass


class BraceError(Exception):
    pass
